from .GeneralSearch import GeneralSearch
from .MemeticSearch import MemeticSearch